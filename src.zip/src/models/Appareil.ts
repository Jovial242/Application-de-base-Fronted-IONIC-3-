export class Appareil {
    //name: string;
    description: string[];
    isOn: boolean;

    constructor(public name: string){
       //  this.name=name;
        this.isOn=false;
    }

}