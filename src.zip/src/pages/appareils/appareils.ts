import { Component}  from '@angular/core';
import {  ModalController, MenuController } from 'ionic-angular';
import {SingleAppareilPage} from './single-appareil/single-appareil';
import { Appareil } from '../../models/Appareil';
import { AppareilsService } from '../../services/appareils.service';


@Component({
selector: 'page-appareils',
templateUrl: 'appareils.html'
})
export class AppareilsPage{

    appareilList: Appareil[];
        

constructor( private modalCtrl: ModalController, 
    private appareilsService: AppareilsService ,
    private menuCtrl: MenuController){}

 /* onLoadAppareils(appareil:{name:string, description:string[]}){ 
   this.navCtrl.push(SingleAppareilPage, {appareil:appareil});
} */


ionViewWillEnter(){
    this.appareilList=this.appareilsService.appareilList.slice();
}

/* onLoadAppareils(appareil:{name:string, description:string[]}){
    let modal=this.modalCtrl.create(SingleAppareilPage, {appareil:appareil});
    modal.present();
} */

onLoadAppareils(index:number){
    let modal=this.modalCtrl.create(SingleAppareilPage, {index:index});
    modal.present();
}

onToggleMenu(){
    this.menuCtrl.open();
}

}

